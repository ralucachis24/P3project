/**
 * 
 * @author raluc
 * Represents a RAM
 */
public class RAM {

	String producer;
	double cap;
	
	/**
	 * Default constructor
	 */
	public RAM() {
		super();
	}

	/**
	 * Parameterized constructor
	 * @param producer
	 * @param cap
	 */
	public RAM(String producer, double cap) {
		super();
		this.producer = producer;
		this.cap = cap;
	}

	/**
	 * Overriding the toString method
	 */
	@Override
	public String toString() {
		return "RAM [producer=" + producer + ", cap=" + cap + "GB]";
	}
	
	/**
	 * Getter method that returns a string representing the name of the producer 
	 * @return 
	 */
	public String getProducer() {
		return producer;
	}

	/**
	 * Getter method that returns the capacity
	 * @return
	 */
	public double getCap() {
		return cap;
	}

	
}
