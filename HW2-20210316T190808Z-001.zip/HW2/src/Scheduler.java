import java.util.Date;
import java.util.TimerTask;

public class Scheduler extends TimerTask {

	String name;

	public Scheduler(String name) {
		super();
		this.name = name;
	}
	
	
	public String getName() {
		return name;
	}


	@Override 
	public void run() {
		
		System.out.println("Task: " + Thread.currentThread().getName() + name + " executed at "+ new Date());
		
		try {
			Thread.sleep(300000);
		} catch (InterruptedException e) {
			e.printStackTrace(); 
		}
	}
	
}
