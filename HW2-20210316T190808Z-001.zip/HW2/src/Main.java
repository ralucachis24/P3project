import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;


/**
 * 
 * @author raluc
 * Main class
 */
public class Main {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
	
		List<PhysicalMachine> machineList = new ArrayList<PhysicalMachine>();
		
		machineList.add(new PhysicalMachine("Machine1", "application1", new CPU("cpu1", 1.0, 24, 7), new RAM("ram1", 2.4), CloudType.AMAZONWEBSERVICE, PhysicalMachineType.VIRTUALMACHINE));
		machineList.add(new PhysicalMachine("Machine2", "application1", new CPU("cpu2", 2.0, 34, 5), new RAM("ram2", 1.4), CloudType.GOOGLECOMPUTEENGINE, PhysicalMachineType.CONTAINER));

		List<Applications> applicationsList = new ArrayList<Applications>();
		
		applicationsList.add(new Applications("application1", 1.3, 2.3, 3)); 
		applicationsList.add(new Applications("application2", 2.4, 1.3, 5)); 
		applicationsList.add(new Applications("application3", 1, 2, 3));
		applicationsList.add(new Applications("application2", 3.7, 2.2, 4));
		applicationsList.add(new Applications("application1", 4, 3.6, 4));
		
		
		runApplications(applicationsList, machineList, "application1"); 
		
		File f = new File("C:\\Users\\raluc\\eclipse-workspace\\HW2");
		
		if(!f.exists())
			f.createNewFile();
		
		boolean empty = f.exists() && f.length() == 0;
		if(empty == false)
			deserializing(applicationsList, f);
		
	}
	
	/**
	 * Function to display the list of physical machines
	 * @param machineList
	 */
	public static void display (List<PhysicalMachine> machineList) {
		
		for(PhysicalMachine m:machineList) {
			System.out.println(m);
		}
		
	}
	
	/**
	 * Function to run the applications from the application list
	 * @param applicationsList
	 * @param machineList
	 * @param name
	 */
	public static void runApplications (List<Applications> applicationsList, List<PhysicalMachine> machineList, String name) {
		
		double RAMavb = 0.0;
		
		Timer t = new Timer();
		
		for(PhysicalMachine m:machineList) {
			
			RAMavb = m.getRAMdet().getCap(); 
			
			for(Applications a:applicationsList) {
				
				if(a.getName().equals(name) && name.equals(m.getApplication())){
					
					int lastApplication = a.getRunTime(); 
					
					if(RAMavb >= a.getRAMres()) {
						
						RAMavb -= a.getRAMres();
						Scheduler task = new Scheduler(a.getName());
						t.scheduleAtFixedRate(task, 0*1000, a.getRunTime()*1000);
						
					}
					else {
					
						Scheduler task = new Scheduler(a.getName());
						t.scheduleAtFixedRate(task, lastApplication*1000, a.getRunTime()*1000);  
						
					}
				} 
			}	
		}	
	} 
	
	
	/**
	 * Object serialization and writing in the file 
	 * @param applicationsList
	 * @param f
	 * @throws IOException
	 */
	public static void serialization(List<Applications> applicationsList, File f) throws IOException {
		
		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(applicationsList);
		oos.close();
		fos.close();
	}
	
	/**
	 * Deserializing  objects written into the file
	 * @param applicationsList
	 * @param f
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static void deserializing(List<Applications> applicationsList, File f) throws IOException, ClassNotFoundException {
		
		FileInputStream fis = new FileInputStream(f);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		List<?> l = (List<?>) ois.readObject();
		
		for(Object o: l)
			applicationsList.add((Applications) o);
		
		ois.close();
		fis.close();
	}
	
	
}
