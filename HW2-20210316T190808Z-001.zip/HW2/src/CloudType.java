/**
 * 
 * @author raluc
 * 	Enumerator for the Cloud types s
 */
public enum CloudType {

	AMAZONWEBSERVICE, GOOGLECOMPUTEENGINE;
	
}
