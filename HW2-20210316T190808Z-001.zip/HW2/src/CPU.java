/**
 * @author raluc
 * Represents a CPU
 */
public class CPU {

	String name;
	double frequency;
	int cache;
	int coreNo;
	
	/**
	 * Default constructor
	 */
	public CPU() {
		super();
	}

	/**
	 * Parameterized constructor
	 * @param name
	 * @param frequency
	 * @param cache
	 * @param coreNo
	 */
	public CPU(String name, double frequency, int cache, int coreNo) {
		super();
		this.name = name;
		this.frequency = frequency;
		this.cache = cache;
		this.coreNo = coreNo;
	}

	/**
	 * Overriding the toString method
	 */
	@Override
	public String toString() {
		return "CPU [name=" + name + ", frequency=" + frequency + "GHz" + ", cache=" + cache + "MB" + ", coreNo=" + coreNo + "]";
	}

	/**
	 * Getter method that returns a string representing the name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Getter method that returns the frequency
	 * @return
	 */
	public double getFrequency() {
		return frequency;
	}

	/**
	 * Getter method that returns the cache size
	 * @return
	 */
	public int getCache() {
		return cache;
	}

	/**
	 * Getter method that returns the number of cores
	 * @return
	 */
	public int getCoreNo() {
		return coreNo;
	} 
	
	
}
