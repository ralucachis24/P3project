/**
 * 
 * @author raluc
 * Represents an application
 */
public class Applications {

	String name;
	double CPUres;
	double RAMres;
	int runTime;
	
	/**
	 * Default constructor
	 */
	public Applications() {
		super();
	}

	/**
	 * Parameterized constructor
	 * @param name
	 * @param CPUres
	 * @param RAMres
	 * @param runTime
	 */
	public Applications(String name,double CPUres, double RAMres, int runTime) {
		super(); 
		this.name = name;
		this.CPUres = CPUres;
		this.RAMres = RAMres; 
		this.runTime = runTime;
	}

	/**
	 * Overrdiding the toString method
	 */
	@Override
	public String toString() {
		return "Applications [name=" + name + ", CPUres=" + CPUres + ", RAMres=" + RAMres + ", runTime=" + runTime
				+ "]";
	}

	/**
	 * Getter method that returns a string representing the name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Getter method that returns the CPU resources needed
	 * @return
	 */
	public double getCPUres() {
		return CPUres;
	}
	
	/**
	 * Getter method that returns the RAM resources needed
	 * @return
	 */
	public double getRAMres() {
		return RAMres;
	}

	/**
	 * Getter method that returns the run time 
	 * @return
	 */
	public int getRunTime() {
		return runTime;
	}

	  
}
