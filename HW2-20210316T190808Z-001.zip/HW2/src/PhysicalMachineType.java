/**
 * 
 * @author raluc
 * Enumerator for the machine type
 */
public enum PhysicalMachineType {
		
	VIRTUALMACHINE, CONTAINER;
	
}
