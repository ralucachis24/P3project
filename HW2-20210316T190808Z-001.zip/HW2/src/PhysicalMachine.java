/**
 * 
 * @author raluc
 * Represents a physical machine
 */
public class PhysicalMachine {

	String name; 
	String application;
	CPU CPUdet; 
	RAM RAMdet;  
	CloudType cloudType;
	PhysicalMachineType machineType;
	
	/**
	 * Default constructor
	 */
	public PhysicalMachine() {
		super();
	}

	/**
	 * Parameterized constructor
	 * @param name
	 * @param application
	 * @param CPUdet
	 * @param RAMdet
	 * @param cloudType
	 * @param machineType
	 */
	public PhysicalMachine(String name, String application, CPU CPUdet, RAM RAMdet,CloudType cloudType, PhysicalMachineType machineType) {
		super();
		this.name = name; 
		this.application = application;
		this.CPUdet = CPUdet;
		this.RAMdet = RAMdet; 
		this.cloudType = cloudType;
		this.machineType = machineType;
	}

	/**
	 * Overriding the toString method
	 */
	@Override
	public String toString() {
		return "PhysicalMachine [name=" + name + ", application=" + application + ", CPUdet=" + CPUdet + ", RAMdet="
				+ RAMdet + ", cloudType=" + cloudType + ", machineType=" + machineType + "]";
	}

	/**
	 * Getter method that returns a string representing the name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Getter method that returns a string representing the application
	 * @return
	 */
	public String getApplication() {
		return application;
	}

	/**
	 * Getter method that returns CPUdetails
	 * @return
	 */
	public CPU getCPUdet() {
		return CPUdet;
	}

	/**
	 * Getter method that returns RAMdetails
	 * @return
	 */
	public RAM getRAMdet() {
		return RAMdet;
	}

	
}
